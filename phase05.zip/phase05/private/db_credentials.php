<?php

// This guide demonstrates the five fundamental steps
// of database interaction using PHP.

// Credentials
define("DB_SERVER", "localhost");
define("DB_USER", "victori1_vicky");
define("DB_PASS", "Pvregi12!");
define("DB_NAME", "victori1_salamanders");

// $connection = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);

// mysqli_close($connection);

?>
